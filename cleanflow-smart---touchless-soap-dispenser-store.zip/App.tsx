
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductSection from './components/ProductSection';
import Features from './components/Features';
import AIAssistant from './components/AIAssistant';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <main>
        <Hero />
        
        {/* Trust & Stats Bar */}
        <section className="bg-slate-50 py-16 border-y border-slate-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div className="p-4 bg-white rounded-2xl shadow-sm border border-slate-100">
                <p className="text-3xl font-bold text-teal-600">0.25s</p>
                <p className="text-xs text-slate-500 uppercase tracking-widest font-bold mt-2">Ultra-Fast Sensing</p>
              </div>
              <div className="p-4 bg-white rounded-2xl shadow-sm border border-slate-100">
                <p className="text-3xl font-bold text-teal-600">480ml</p>
                <p className="text-xs text-slate-500 uppercase tracking-widest font-bold mt-2">Large Tank</p>
              </div>
              <div className="p-4 bg-white rounded-2xl shadow-sm border border-slate-100">
                <p className="text-3xl font-bold text-teal-600">Type-C</p>
                <p className="text-xs text-slate-500 uppercase tracking-widest font-bold mt-2">Fast Charging</p>
              </div>
              <div className="p-4 bg-white rounded-2xl shadow-sm border border-slate-100">
                <p className="text-3xl font-bold text-teal-600">LED</p>
                <p className="text-xs text-slate-500 uppercase tracking-widest font-bold mt-2">Smart Display</p>
              </div>
            </div>
          </div>
        </section>

        <Features />
        
        <ProductSection />

        {/* Shopify Integration Section */}
        <section className="py-20 bg-slate-900 overflow-hidden relative">
          <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-96 h-96 bg-teal-500/10 blur-3xl rounded-full"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="lg:flex items-center gap-16">
              <div className="lg:w-1/2 mb-12 lg:mb-0">
                <div className="inline-flex items-center space-x-2 bg-white/10 px-4 py-2 rounded-full mb-6">
                  <i className="fa-brands fa-shopify text-[#95bf47] text-xl"></i>
                  <span className="text-white font-medium text-sm">Shopify Certified Integration</span>
                </div>
                <h2 className="text-4xl font-bold text-white mb-6">Built for Modern <span className="text-[#95bf47]">Shopify Stores</span></h2>
                <p className="text-slate-400 text-lg mb-8 leading-relaxed">
                  Export this landing page directly to your Shopify store. Optimized for high conversions, lightning-fast load times, and seamless one-click checkout.
                </p>
                <ul className="space-y-4">
                  {[
                    "One-click sync with Shopify Products",
                    "Optimized for mobile-first shoppers",
                    "Native DSers & Oberlo support",
                    "Integrated Shopify Analytics tracking"
                  ].map((item, idx) => (
                    <li key={idx} className="flex items-center space-x-3 text-slate-300">
                      <i className="fa-solid fa-check-circle text-[#95bf47]"></i>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="lg:w-1/2 bg-white/5 border border-white/10 p-2 rounded-[2rem] backdrop-blur-sm">
                <div className="bg-slate-800 rounded-[1.8rem] p-8">
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex space-x-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                    <div className="text-slate-500 text-xs font-mono">shopify-theme-validator.v1</div>
                  </div>
                  <div className="space-y-4 font-mono text-sm">
                    <div className="text-green-400 flex items-center"><i className="fa-solid fa-check mr-3"></i> Found layout/theme.liquid</div>
                    <div className="text-green-400 flex items-center"><i className="fa-solid fa-check mr-3"></i> Found templates/index.liquid</div>
                    <div className="text-green-400 flex items-center"><i className="fa-solid fa-check mr-3"></i> Assets validated successfully</div>
                    <div className="text-teal-400 animate-pulse mt-6">Ready for upload to Online Store...</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Technical Detailed Specs */}
        <section id="specs" className="py-24 bg-white border-t border-slate-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-extrabold text-slate-900 mb-4">Inside the Innovation</h2>
              <p className="text-slate-500">High-grade engineering for your peace of mind.</p>
            </div>
            <div className="divide-y divide-slate-100 border-t border-b border-slate-100 bg-slate-50/30 rounded-3xl p-6 sm:p-10">
              <div className="py-5 flex flex-col sm:flex-row sm:justify-between space-y-2 sm:space-y-0">
                <span className="font-semibold text-slate-600">Battery Type</span>
                <span className="text-slate-900 font-medium">1200mAh Lithium-Ion (USB-C)</span>
              </div>
              <div className="py-5 flex flex-col sm:flex-row sm:justify-between space-y-2 sm:space-y-0">
                <span className="font-semibold text-slate-600">Liquid Compatibility</span>
                <span className="text-slate-900 font-medium">Foam Soap, Hand Sanitizer (Thin)</span>
              </div>
              <div className="py-5 flex flex-col sm:flex-row sm:justify-between space-y-2 sm:space-y-0">
                <span className="font-semibold text-slate-600">Waterproof Rating</span>
                <span className="text-slate-900 font-medium">IPX5 Splash Resistant</span>
              </div>
              <div className="py-5 flex flex-col sm:flex-row sm:justify-between space-y-2 sm:space-y-0">
                <span className="font-semibold text-slate-600">Installation</span>
                <span className="text-slate-900 font-medium">Wall Mounted (Adhesive Sticker included)</span>
              </div>
              <div className="py-5 flex flex-col sm:flex-row sm:justify-between space-y-2 sm:space-y-0">
                <span className="font-semibold text-slate-600">Sensing Speed</span>
                <span className="text-slate-900 font-medium">0.25 Seconds (Industry Leading)</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      
      <AIAssistant />
    </div>
  );
};

export default App;
