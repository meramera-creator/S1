
export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  description: string;
  features: string[];
  specs: Record<string, string>;
  images: string[];
}

export interface Review {
  id: number;
  author: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Message {
  role: 'user' | 'assistant';
  content: string;
}
