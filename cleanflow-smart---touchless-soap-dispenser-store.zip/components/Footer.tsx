
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
            <span className="text-3xl font-bold bg-gradient-to-r from-teal-400 to-cyan-400 bg-clip-text text-transparent mb-6 block">CleanFlow Smart</span>
            <p className="text-slate-400 max-w-sm mb-8 leading-relaxed">
              Redefining daily hygiene with smart technology. Our goal is to make every home safer and cleaner through touchless innovation.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-slate-400 hover:text-white transition-all transform hover:-translate-y-1"><i className="fa-brands fa-facebook-f text-xl"></i></a>
              <a href="#" className="text-slate-400 hover:text-white transition-all transform hover:-translate-y-1"><i className="fa-brands fa-instagram text-xl"></i></a>
              <a href="#" className="text-slate-400 hover:text-white transition-all transform hover:-translate-y-1"><i className="fa-brands fa-tiktok text-xl"></i></a>
            </div>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-6">Explore</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#product" className="hover:text-teal-400 transition-colors">Shop Now</a></li>
              <li><a href="#features" className="hover:text-teal-400 transition-colors">How it Works</a></li>
              <li><a href="#" className="hover:text-teal-400 transition-colors">Refill Guide</a></li>
              <li><a href="#" className="hover:text-teal-400 transition-colors">Wholesale</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-6">Customer Care</h4>
            <ul className="space-y-4 text-slate-400">
              <li className="flex items-center hover:text-white transition-colors cursor-pointer"><i className="fa-solid fa-envelope mr-3 text-teal-500"></i> help@cleanflow.smart</li>
              <li className="flex items-center hover:text-white transition-colors cursor-pointer"><i className="fa-solid fa-clock mr-3 text-teal-500"></i> 24/7 AI Support</li>
              <li className="flex items-center hover:text-white transition-colors cursor-pointer"><i className="fa-solid fa-truck-fast mr-3 text-teal-500"></i> Track Order</li>
            </ul>
          </div>
        </div>
        <div className="pt-8 border-t border-slate-800 text-center text-slate-500 text-sm">
          &copy; {new Date().getFullYear()} CleanFlow Smart. Elevating your sink experience.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
