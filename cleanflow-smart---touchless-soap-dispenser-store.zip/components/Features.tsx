
import React from 'react';

const Features: React.FC = () => {
  const highlights = [
    { icon: 'fa-hand-sparkles', title: 'Full Touchless', desc: 'Prevent cross-contamination with advanced IR sensors that detect your hands in 0.25s.' },
    { icon: 'fa-temperature-half', title: 'Smart LED Display', desc: 'Built-in screen shows real-time room temperature and time for added convenience.' },
    { icon: 'fa-wall-layer', title: 'Space Saving', desc: 'Easy wall mounting clears your counter space. Includes extra-strength adhesive bracket.' },
    { icon: 'fa-battery-full', title: 'USB-C Charging', desc: 'Eco-friendly 1200mAh battery lasts up to 3-4 months on a single 1-hour charge.' },
  ];

  return (
    <section id="features" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-base font-semibold text-teal-600 tracking-wide uppercase">Innovative Hygiene</h2>
          <p className="mt-2 text-4xl font-extrabold text-slate-900 tracking-tight">Smart Solutions for Every Sink</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {highlights.map((h, i) => (
            <div key={i} className="group p-8 bg-slate-50 rounded-2xl hover:bg-white hover:shadow-2xl hover:-translate-y-2 transition-all border border-slate-100">
              <div className="w-14 h-14 bg-teal-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-teal-600 group-hover:rotate-6 transition-all duration-300">
                <i className={`fa-solid ${h.icon} text-2xl text-teal-600 group-hover:text-white`}></i>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">{h.title}</h3>
              <p className="text-slate-500 leading-relaxed text-sm">{h.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
