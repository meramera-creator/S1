
import React from 'react';

const Navbar: React.FC = () => {
  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <span className="text-2xl font-bold gradient-text tracking-tight">CleanFlow Smart</span>
          </div>
          <div className="hidden md:flex space-x-8 text-sm font-medium text-slate-600">
            <a href="#features" className="hover:text-teal-600 transition-colors">Features</a>
            <a href="#specs" className="hover:text-teal-600 transition-colors">Specifications</a>
            <a href="#reviews" className="hover:text-teal-600 transition-colors">Reviews</a>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 text-slate-500 hover:text-slate-900 transition-colors">
              <i className="fa-solid fa-magnifying-glass"></i>
            </button>
            <button className="p-2 text-slate-500 hover:text-slate-900 transition-colors relative">
              <i className="fa-solid fa-cart-shopping"></i>
              <span className="absolute top-1 right-1 bg-teal-600 text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full">0</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
