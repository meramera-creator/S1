
import React, { useState } from 'react';
import { PRODUCT_DATA } from '../constants';

const ProductSection: React.FC = () => {
  const [activeImg, setActiveImg] = useState(0);

  return (
    <section id="product" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-12 bg-white rounded-3xl p-8 shadow-sm border border-slate-100">
          {/* Gallery */}
          <div>
            <div className="aspect-square bg-slate-100 rounded-2xl overflow-hidden mb-4 border border-slate-100 relative group">
              <img 
                src={PRODUCT_DATA.images[activeImg]} 
                alt={PRODUCT_DATA.name} 
                className="w-full h-full object-cover transition-opacity duration-300"
              />
              <div className="absolute bottom-4 left-4 right-4 flex justify-center space-x-2">
                 {PRODUCT_DATA.images.map((_, i) => (
                   <div key={i} className={`h-1.5 rounded-full transition-all ${activeImg === i ? 'w-6 bg-teal-600' : 'w-2 bg-white/60'}`}></div>
                 ))}
              </div>
            </div>
            <div className="grid grid-cols-4 gap-4">
              {PRODUCT_DATA.images.map((img, idx) => (
                <button 
                  key={idx} 
                  onClick={() => setActiveImg(idx)}
                  className={`aspect-square rounded-xl overflow-hidden border-2 transition-all ${activeImg === idx ? 'border-teal-600 ring-4 ring-teal-50' : 'border-transparent opacity-60 hover:opacity-100'}`}
                >
                  <img src={img} alt={`View ${idx}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Details */}
          <div className="mt-8 lg:mt-0 flex flex-col justify-center">
            <div className="flex items-center space-x-2 mb-4">
              <div className="flex text-amber-400">
                {[1, 2, 3, 4, 5].map((s) => <i key={s} className="fa-solid fa-star text-xs"></i>)}
              </div>
              <span className="text-sm font-medium text-slate-500">4.9 (340+ Verified Orders)</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">{PRODUCT_DATA.name}</h2>
            <div className="flex items-baseline space-x-4 mb-6">
              <span className="text-4xl font-bold text-teal-600">${PRODUCT_DATA.price}</span>
              <span className="text-xl text-slate-400 line-through">${PRODUCT_DATA.originalPrice}</span>
              <span className="bg-teal-100 text-teal-700 text-xs font-bold px-2 py-1 rounded uppercase tracking-wider">Top Rated</span>
            </div>
            <p className="text-slate-600 mb-8 leading-relaxed text-lg">
              {PRODUCT_DATA.description}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              {PRODUCT_DATA.features.map((f, i) => (
                <div key={i} className="flex items-center space-x-3 bg-slate-50 p-3 rounded-lg border border-slate-100">
                  <i className="fa-solid fa-circle-check text-teal-600"></i>
                  <span className="text-slate-700 text-sm font-medium">{f}</span>
                </div>
              ))}
            </div>

            <button className="w-full bg-teal-600 text-white py-5 rounded-xl font-bold text-lg hover:bg-teal-700 transition-all shadow-xl shadow-teal-100 flex items-center justify-center space-x-3 group active:scale-95">
              <i className="fa-solid fa-cart-plus group-hover:animate-bounce"></i>
              <span>Add to Cart - Free Shipping</span>
            </button>
            <div className="flex justify-center items-center space-x-6 mt-6">
               <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" className="h-4 opacity-50 grayscale hover:grayscale-0 transition-all cursor-pointer" />
               <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="Visa" className="h-4 opacity-50 grayscale hover:grayscale-0 transition-all cursor-pointer" />
               <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard" className="h-6 opacity-50 grayscale hover:grayscale-0 transition-all cursor-pointer" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductSection;
