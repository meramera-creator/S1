
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-white pt-16 pb-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
          <div className="mb-12 lg:mb-0">
            <div className="inline-block px-4 py-1.5 mb-6 text-sm font-semibold tracking-wide text-teal-700 uppercase bg-teal-100 rounded-full">
              Smart Hygiene Evolution
            </div>
            <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight text-slate-900 mb-6">
              Touchless Hygiene, <span className="gradient-text">Zero Compromise</span>
            </h1>
            <p className="text-xl text-slate-500 mb-8 max-w-lg leading-relaxed">
              Experience the perfect foam every time. Our 480ml Smart Dispenser features 0.25s sensing and a built-in LED display for the ultimate modern bathroom.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <a href="#product" className="bg-teal-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100 text-center">
                Order Now - $29.99
              </a>
              <a href="#features" className="bg-white text-slate-700 border border-slate-200 px-8 py-4 rounded-xl font-semibold hover:bg-slate-50 transition-all text-center">
                View Features
              </a>
            </div>
            <div className="mt-10 flex items-center space-x-6 text-sm text-slate-400">
              <span className="flex items-center"><i className="fa-solid fa-battery-full mr-2 text-teal-500"></i> 90-Day Battery</span>
              <span className="flex items-center"><i className="fa-solid fa-droplet mr-2 text-teal-500"></i> 480ml Capacity</span>
            </div>
          </div>
          <div className="relative">
            <div className="absolute -top-10 -right-10 w-64 h-64 bg-teal-50 rounded-full blur-3xl opacity-60"></div>
            <div className="relative bg-slate-100 rounded-[2.5rem] overflow-hidden shadow-2xl border border-white/40 group">
              <img 
                src="https://images.unsplash.com/photo-1584622781564-1d9876a13d00?q=80&w=1200&auto=format&fit=crop" 
                alt="CleanFlow Smart Dispenser" 
                className="w-full h-auto object-cover transform transition-transform duration-1000 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
