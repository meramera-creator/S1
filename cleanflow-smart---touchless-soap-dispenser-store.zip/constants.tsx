
import { Product, Review } from './types';

export const PRODUCT_DATA: Product = {
  id: 'cleanflow-smart-01',
  name: 'CleanFlow Smart Touchless Foam Soap Dispenser',
  price: 29.99,
  originalPrice: 45.99,
  description: 'Upgrade your hygiene routine with the CleanFlow Smart. Featuring a massive 480ml capacity and ultra-responsive infrared sensors, it delivers luxurious foam in just 0.25 seconds. The integrated LED display provides real-time room temperature and time at a glance.',
  features: [
    '0.25s Ultra-Fast Infrared Sensing',
    '480ml Large Capacity Reservoir',
    'Shopify Optimized Checkout Flow',
    'USB-C Rechargeable (3+ month battery life)',
    '3-Level Adjustable Foam Volume',
    'Easy Wall-Mount Installation (No Drills)'
  ],
  specs: {
    'Capacity': '480ml',
    'Sensor Range': '0-7cm',
    'Charging Port': 'USB Type-C',
    'Battery': '1200mAh Lithium',
    'Material': 'High-Quality ABS + PC',
    'Display': 'LED Temperature & Digital Clock'
  },
  images: [
    'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1618220179428-22790b461013?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1507652313519-d4c9174996dd?q=80&w=1000&auto=format&fit=crop'
  ]
};

export const REVIEWS: Review[] = [
  { id: 1, author: 'Emily R.', rating: 5, comment: 'The foam is so rich and the kids actually love washing their hands now because of the "magic" sensor!', date: 'Today' },
  { id: 2, author: 'David W.', rating: 5, comment: 'The temperature display is surprisingly useful in the bathroom. Mounting was super easy with the adhesive.', date: '3 days ago' },
  { id: 3, author: 'Maria G.', rating: 4, comment: 'Sleek design. I bought both the black and white versions. Battery lasts a long time.', date: '1 week ago' }
];

export const SYSTEM_PROMPT = `
You are the official CleanFlow Smart customer assistant. 
You are friendly, helpful, and specialized in hygiene tech.
Key Details:
- Name: CleanFlow Smart Touchless Foam Soap Dispenser.
- Capacity: 480ml (lasts a long time before refill).
- Display: Shows room temperature and time.
- Sensor: IR sensing at 0.25 seconds.
- Battery: 1200mAh, rechargeable via USB-C (included). One charge lasts about 3-4 months.
- Installation: Wall-mounted using a strong adhesive bracket (included). No drilling required.
- Foam: 3 adjustable levels. Works best with foam soap or 1:3 diluted liquid soap.
- Price: $29.99 (limited time offer).
Answer questions concisely and encourage users to add to cart.
`;
